# -*- coding: utf-8 -*-
"""
Created on Thu Feb 16 11:15:10 2017

@author: Ashwini
"""

import pandas as pd
from sklearn.linear_model import LinearRegression 
from sklearn.preprocessing import PolynomialFeatures


#file load

#import pandas as pd
Data = pd.read_csv('Data.txt', sep=" ", header=None)   
#print(Data)
#print(Data.ix[:,1])


X=Data.ix[:,0:1]
Y=Data.ix[:,2]


pr_model= PolynomialFeatures(degree=4)
X_poly=pr_model.fit_transform(X)


lr_model = LinearRegression()
lr_model.fit(X_poly,Y)

Test=pd.read_csv('Test.txt', sep=" ", header=None)   
#print(Test)

X_test=Test.ix[:,0:1]
Y_test=Test.ix[:,2]

expected = Y_test
predicted = lr_model.predict(pr_model.fit_transform(X_test))
#print(expected, predicted)
i=0
#print(X_test)

print("Polynomial Degree: 4")
print("expected \t predicted \t Normalized Distance")
for i in range(0,len(expected)-1):
    print(expected[i],"\t",predicted[i],"\t", ((expected[i]-predicted[i])/expected[i]))
    
#print(expected,predicted)


